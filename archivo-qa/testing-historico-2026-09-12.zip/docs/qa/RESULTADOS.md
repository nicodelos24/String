# Resultados de pruebas

## Revisión vigente — 2026-09-11

Base: `4aee85c` más cambios locales. Windows, PowerShell, Node.js v24.16.0. Ejecuciones con asistencia de IA; **0 casos manuales ejecutados formalmente en esta revisión y 38 pendientes**.

| Ejecución | Resultado | Evidencia |
| --- | --- | --- |
| npm test | 66 pruebas aprobadas, 0 fallidas | [Salida Node](evidencia/revision-2026-09-11/node-tests.txt) |
| Interfaz Chrome 152.0.7977.84 | Aprobada | [Informe](evidencia/revision-2026-09-11/interface-chrome.json) |
| Interfaz Edge 152.0.4191.66 | Aprobada | [Informe](evidencia/revision-2026-09-11/interface-edge.json) |
| Tema, iconos y pentatónicas en Chrome | Aprobada | [Informe](evidencia/revision-2026-09-11/view-chrome.json) |
| Audio y ritmos en Chrome, file:// | Aprobada | [Informe](evidencia/revision-2026-09-11/audio-chrome.json) |

El [registro consolidado](evidencia/revision-2026-09-11/ejecucion.json) contiene comandos, límites y el incidente del fixture de respaldo que se amplió antes de la ejecución final. Las regresiones de BUG-009 a BUG-014 están vinculadas en [BUGS.md](BUGS.md).

Se comprobaron importación de respaldo válido mayor a 2 MB, rechazo de tamaño excesivo sin sobrescritura, foco en una sección filtrada, selección de fuente activa sin detención, icono de detener, reapertura de paneles e índices duplicados. La prueba de estructura valida IDs activos y scripts únicos.

### Alcance real de la evidencia

- Chrome/Edge de escritorio, perfiles temporales, modo headless y audio silenciado.
- La comprobación de interfaz usa movimiento reducido para medir alturas; el script visual separado ejercita los switches. Clics muy rápidos, lector de pantalla y comodidad de animación quedan en los casos manuales.
- YouTube simulado en la interfaz: no se probó una cuenta ni la reproducción de un video externo real.
- Audio offline evaluó doce raíces y seis estilos (pop, jazz, trap, funk, bossa y reggaetón). Reggae, disco y balada tienen pruebas de programación en Node; no se certifica su percepción auditiva.
- No se midió un porcentaje de cobertura. No se probaron Safari, Firefox ni teléfonos físicos.
- BUG-006 y BUG-008 históricos conservan pendiente la aceptación auditiva.

Capturas de referencia: [escritorio](evidencia/revision-2026-09-11/interface-chrome.png), [móvil emulado](evidencia/revision-2026-09-11/interface-mobile-chrome.png), [tema oscuro](evidencia/revision-2026-09-11/tema-oscuro.png), [tema claro](evidencia/revision-2026-09-11/tema-claro.png). No constituyen una ejecución manual.

### Entregables actuales

- [Casos de prueba String.xlsx](excel/Casos_de_prueba_String.xlsx): 38 casos manuales pendientes y resultados automáticos separados.
- [Reporte de bugs String.xlsx](excel/Reporte_de_bugs_String.xlsx): seis defectos de esta revisión y referencias al historial.
- [Fuente editable](REVISION-ACTUAL.json) y `python scripts/generate-qa-current.py`.

## Historial conservado

Los registros siguientes pertenecen a etapas anteriores. Sus cantidades y estados no describen la suite actual.

## Ejecución automatizada — 2026-09-09

- Entorno: Windows, PowerShell, Node.js v24.16.0.
- Comando: `node --test tests/*.test.cjs` desde la raíz.
- Revisión: cambios locales del primer reproductor sobre `5aed427`; sin commit propio todavía.
- Resultado: **25 pruebas, 25 aprobadas, 0 fallidas, 0 omitidas**.
- Alcance: lógica musical, progresiones, metrónomo, motor de reproducción y conexión de sus controles con datos de la app.
- Evidencia resumida del runner:

```text
tests 25
pass 25
fail 0
cancelled 0
skipped 0
todo 0
```

La suite anterior tenía 12 pruebas; se agregaron 11 del motor y 2 de integración de controles. No se midió cobertura porcentual. `git diff --check` también terminó sin errores de espacios.

## Reporte exploratorio del usuario y corrección posterior

El usuario abrió `index.html` con doble clic y reportó un acorde suave que sonaba una sola vez, sin avanzar ni repetir, junto al mensaje de error. También esperaba que cambiar la selección cambiara lo reproducido. Registrado como BUG-005, BUG-006 y BUG-007. No se presentó una captura ni una ejecución formal de los casos MAN; se conserva como reporte exploratorio.

### Resultado automatizado tras corregir BUG-005

- `node --test tests/*.test.cjs`: **27 aprobadas, 0 fallidas**.
- PLY-14 cubre el contexto requerido por los temporizadores del navegador, que los dobles anteriores no detectaban.
- PLY-15 comprueba la envolvente con volumen sostenido; no mide la percepción del sonido.
- Chrome 152.0.7977.83 y Edge 152.0.4191.66: se usó el archivo local, modo headless y audio silenciado. Se comprobó cambio de acordes, repetición y detención con Web Audio real.
- La comprobación ampliada también cambia la progresión guardada a F#m, verifica frecuencias distintas y su finalización sin repetir.
- La comprobación anterior a la corrección programaba únicamente las tres notas de C y devolvía `TypeError: Illegal invocation`. Después se programan las sucesivas tarjetas y la vuelta siguiente.

Comandos separados de la suite de Node:

```sh
node scripts/check-player-browser.cjs
node scripts/check-player-browser.cjs --edge
```

El script requiere Chrome o Edge instalado. Usa un perfil temporal aislado, sin acceder al perfil personal. Las fechas de los registros JSON están en UTC.

Evidencia:

- [Antes de la corrección: Chrome](evidencia/reproductor-antes.json).
- [Después de la corrección: Chrome](evidencia/reproductor-despues.json).
- [Después de la corrección: Edge](evidencia/reproductor-despues-edge.json).
- [Primer intento en Edge](evidencia/reproductor-intento-edge.json): la comprobación terminó antes de que el reloj de audio llegara a la repetición. Se reemplazó la espera fija por espera del estado esperado con límite de tiempo. No se clasificó como un nuevo bug de la app.

### Pendiente de verificación manual

Falta escuchar el volumen y la calidad del sonido, comprobar la comodidad de la interfaz y ejecutar los [casos manuales](CASOS-MANUALES.md). Una ejecución automatizada en headless no equivale a una escucha humana. Los bugs de percepción de volumen y claridad del mensaje siguen pendientes de revalidación manual.

## Archivos Excel

- [Reporte de bugs](excel/Reporte_de_bugs_Traste.xlsx): registro, ficha por bug y plantilla.
- [Casos de prueba](excel/Casos_de_prueba_Traste.xlsx): casos, ejecuciones y cobertura automatizada.

Se generaron con `python scripts/generate-qa-excel.py` (requiere `openpyxl`) y se reabrieron para validar hojas, tablas y contenido. No se comprobó su apariencia dentro de Microsoft Excel. Guardar las ejecuciones personales en una copia: regenerar reemplaza los archivos de ejemplo.

## Etapa de ritmos y balance — 2026-09-10

### Lo que confirmó el usuario

- EXP-002-A: ahora se reproduce sonido. Aprobación limitada a ese comportamiento; no se extiende a todos los casos manuales.
- EXP-002-B: algunas notas suenan más fuertes que otras. Resultado fallido para el balance, registrado como BUG-008. El usuario no identificó todavía las notas, BPM ni salida de audio exactos.
- Los estilos y el nuevo timbre se implementaron después de ese comentario: su aceptación manual está pendiente.

### Verificación automatizada

- Suite Node: **34 pruebas aprobadas, 0 fallidas**. Se sumaron RIT-01 a RIT-06 y MIX-01 a las 27 anteriores.
- Chrome 152 y Edge 152: repetición y detención del flujo base, reproducción de una progresión distinta y ejecución de los tres estilos nuevos con Web Audio real.
- OfflineAudioContext: 12 tríadas mayores en distintas raíces y tres patrones renderizados. Se midieron RMS y picos, y silencio después de la finalización.
- Los valores corresponden a 240 BPM y volumen general 35%, en la ventana medida. No prueban todos los instrumentos de salida ni sustituyen la escucha del usuario.
- Captura de escritorio revisada: los nuevos controles se muestran completos. Revisión móvil y de teclado sigue pendiente.

Evidencia: [Chrome](evidencia/reproductor-ritmos-chrome.json), [Edge](evidencia/reproductor-ritmos-edge.json), [captura de escritorio](evidencia/ritmos-chrome.png).

### Planillas de esta etapa

- [Bugs — edición Ritmos](excel/Reporte_de_bugs_Traste_Ritmos.xlsx): agrega BUG-008.
- [Casos — edición Ritmos](excel/Casos_de_prueba_Traste_Ritmos.xlsx): agrega MAN-14 a MAN-18, el reporte manual y las comprobaciones automatizadas.

Generación: `python scripts/generate-qa-excel.py --rhythms`. Se crean archivos con sufijo `_Ritmos`, conservando los Excel anteriores. Las siguientes ejecuciones del generador reemplazan solo esa edición; guardar las anotaciones personales en una copia.
